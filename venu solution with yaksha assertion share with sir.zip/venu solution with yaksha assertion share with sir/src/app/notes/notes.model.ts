export class NotesModel {
    id:number=0;
    title:string='';
    author:string='';
    description:string='';
    status:string='';
}